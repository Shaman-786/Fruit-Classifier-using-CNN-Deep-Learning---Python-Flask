Fruit Classifier Project

1. Place the fruit dataset from Kaggle into:
   dataset/Training/
   dataset/Test/

2. Train the model:
   python main.py

3. Upload your test image to:
   test_image/your_uploaded_image.jpg

4. Predict:
   python predict.py

Enjoy! 🍎🍌🍊