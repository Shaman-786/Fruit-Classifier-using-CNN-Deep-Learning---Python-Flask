import os
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# Parameters
img_height, img_width = 100, 100
model_path = 'model/fruit_model.h5'
image_path = 'test_image/your_uploaded_image.jpg'  # Replace this

# Load Model
if not os.path.exists(model_path):
    raise Exception("Trained model not found! Please run main.py first.")

model = load_model(model_path)

# Load Class Labels
train_dir = 'dataset/Training'
class_labels = sorted(os.listdir(train_dir))

# Load Image
if not os.path.exists(image_path):
    raise Exception(f"Image not found: {image_path}")

img = load_img(image_path, target_size=(img_height, img_width))
img_array = img_to_array(img)
img_array = np.expand_dims(img_array, axis=0) / 255.0

# Predict
prediction = model.predict(img_array)[0]
class_index = np.argmax(prediction)
confidence = prediction[class_index] * 100

# Output
print(f"🧠 Predicted Fruit: {class_labels[class_index]}")
print(f"✅ Confidence: {confidence:.2f}%")